package ExpositoTOP.src.top;

public class TOPTWEvaluator {
    public static final double NO_EVALUATED = -1.0;

    public void evaluate(TOPTWSolution solution) {
    	System.out.println("Evaluate "+ solution);
    }
}
